package jp.naohi.taczammunition;

import com.tacz.guns.item.AmmoBoxItem;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;

/**
 * Reuses TaCZ's inventory interaction and tooltip behavior while assigning a
 * fixed capacity tier to this separate item id.
 */
public final class TieredAmmoBoxItem extends AmmoBoxItem {
    private final int ammoLevel;
    private final String translationKey;

    public TieredAmmoBoxItem(int ammoLevel, String translationKey) {
        this.ammoLevel = ammoLevel;
        this.translationKey = translationKey;
    }

    @Override
    public int getAmmoLevel(ItemStack stack) {
        return ammoLevel;
    }

    @Override
    public Component getName(ItemStack stack) {
        return Component.translatable(translationKey);
    }
}

package jp.taczammunition;

import com.tacz.guns.init.ModCreativeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.Mod;

@Mod(TaczAmmoTiers.MOD_ID)
public final class TaczAmmoTiers {
    public static final String MOD_ID = "tacz_ammo_tiers";

    public TaczAmmoTiers(IEventBus modEventBus) {
        TierAmmoBoxes.ITEMS.register(modEventBus);
        modEventBus.addListener(this::addToAmmoTab);
    }

    private void addToAmmoTab(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey().equals(ModCreativeTabs.AMMO_TAB.getKey())) {
            event.accept(TierAmmoBoxes.COPPER_AMMO_BOX);
            event.accept(TierAmmoBoxes.EMERALD_AMMO_BOX);
            event.accept(TierAmmoBoxes.NETHERITE_AMMO_BOX);
        }
    }
}

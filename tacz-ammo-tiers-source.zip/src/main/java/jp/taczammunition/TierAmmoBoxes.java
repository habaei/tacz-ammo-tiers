package jp.taczammunition;

import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.minecraft.world.item.Item;

public final class TierAmmoBoxes {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(TaczAmmoTiers.MOD_ID);

    public static final DeferredItem<TieredAmmoBoxItem> COPPER_AMMO_BOX = ITEMS.register(
            "copper_ammo_box", () -> new TieredAmmoBoxItem(1, "item.tacz_ammo_tiers.copper_ammo_box"));
    public static final DeferredItem<TieredAmmoBoxItem> EMERALD_AMMO_BOX = ITEMS.register(
            "emerald_ammo_box", () -> new TieredAmmoBoxItem(3, "item.tacz_ammo_tiers.emerald_ammo_box"));
    public static final DeferredItem<TieredAmmoBoxItem> NETHERITE_AMMO_BOX = ITEMS.register(
            "netherite_ammo_box", () -> new TieredAmmoBoxItem(4, "item.tacz_ammo_tiers.netherite_ammo_box"));

    private TierAmmoBoxes() {
    }
}
